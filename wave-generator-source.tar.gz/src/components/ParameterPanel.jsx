import React from 'react';
import { teachingPresets } from '../utils/presets';

export default function ParameterPanel({ params, onParamsChange, colorScheme, onColorSchemeChange }) {
  const handleSliderChange = (param, value) => {
    onParamsChange({ ...params, [param]: parseFloat(value) });
  };

  const handleCheckboxChange = (param, checked) => {
    onParamsChange({ ...params, [param]: checked });
  };

  const applyPreset = (preset) => {
    onParamsChange({
      ...params,
      amplitude: preset.amplitude,
      wavelength: preset.wavelength,
      phase: preset.phase
    });
  };

  return (
    <div className="parameter-panel">
      <h2>🎛 參數設定</h2>
      
      <div className="param-group">
        <label>
          <span>振幅 A:</span>
          <input
            type="range"
            min="0.1"
            max="3"
            step="0.1"
            value={params.amplitude}
            onChange={(e) => handleSliderChange('amplitude', e.target.value)}
          />
          <span className="value">{params.amplitude.toFixed(1)}</span>
        </label>
      </div>

      <div className="param-group">
        <label>
          <span>波長 λ:</span>
          <input
            type="range"
            min="0.5"
            max="4"
            step="0.1"
            value={params.wavelength}
            onChange={(e) => handleSliderChange('wavelength', e.target.value)}
          />
          <span className="value">{params.wavelength.toFixed(1)}</span>
        </label>
      </div>

      <div className="param-group">
        <label>
          <span>相位 φ:</span>
          <input
            type="range"
            min="0"
            max="360"
            step="15"
            value={params.phase}
            onChange={(e) => handleSliderChange('phase', e.target.value)}
          />
          <span className="value">{params.phase}°</span>
        </label>
      </div>

      <div className="divider"></div>

      <h3>📁 快速選擇</h3>
      <div className="presets">
        {Object.entries(teachingPresets).map(([category, presets]) => (
          <div key={category} className="preset-category">
            <h4>{category}</h4>
            {presets.map((preset, idx) => (
              <button
                key={idx}
                className="preset-btn"
                onClick={() => applyPreset(preset)}
              >
                {preset.name}
              </button>
            ))}
          </div>
        ))}
      </div>

      <div className="divider"></div>

      <h3>🎨 配色方案</h3>
      <div className="color-schemes">
        <label>
          <input
            type="radio"
            name="colorScheme"
            value="projection"
            checked={colorScheme === 'projection'}
            onChange={(e) => onColorSchemeChange(e.target.value)}
          />
          投影模式
        </label>
        <label>
          <input
            type="radio"
            name="colorScheme"
            value="blackWhite"
            checked={colorScheme === 'blackWhite'}
            onChange={(e) => onColorSchemeChange(e.target.value)}
          />
          黑白模式
        </label>
        <label>
          <input
            type="radio"
            name="colorScheme"
            value="dark"
            checked={colorScheme === 'dark'}
            onChange={(e) => onColorSchemeChange(e.target.value)}
          />
          深色模式
        </label>
      </div>

      <div className="divider"></div>

      <h3>📊 顯示選項</h3>
      <div className="display-options">
        <label>
          <input
            type="checkbox"
            checked={params.showWavelengthAnnotation}
            onChange={(e) => handleCheckboxChange('showWavelengthAnnotation', e.target.checked)}
          />
          顯示波長標註
        </label>
        <label>
          <input
            type="checkbox"
            checked={params.showAmplitudeAnnotation}
            onChange={(e) => handleCheckboxChange('showAmplitudeAnnotation', e.target.checked)}
          />
          顯示振幅標註
        </label>
        <label>
          <input
            type="checkbox"
            checked={params.showGrid}
            onChange={(e) => handleCheckboxChange('showGrid', e.target.checked)}
          />
          顯示網格
        </label>
      </div>

      <div className="divider"></div>

      <div className="animation-control">
        <label>
          <input
            type="checkbox"
            checked={params.enableAnimation}
            onChange={(e) => handleCheckboxChange('enableAnimation', e.target.checked)}
          />
          啟用動畫
        </label>
      </div>
    </div>
  );
}
