export const colorSchemes = {
  projection: {
    name: '投影模式',
    background: '#FFFFFF',
    axis: '#000000',
    wave: '#0066CC',
    grid: '#CCCCCC',
    labels: '#000000',
    annotation: '#CC0000',
    lineWidth: 3
  },
  
  blackWhite: {
    name: '黑白模式',
    background: '#FFFFFF',
    axis: '#000000',
    wave: '#000000',
    grid: '#E0E0E0',
    labels: '#000000',
    annotation: '#666666',
    lineWidth: 2
  },
  
  dark: {
    name: '深色模式',
    background: '#1E1E1E',
    axis: '#FFFFFF',
    wave: '#00D9FF',
    grid: '#404040',
    labels: '#FFFFFF',
    annotation: '#FF6B6B',
    lineWidth: 3
  }
};

export const defaultScheme = 'projection';
