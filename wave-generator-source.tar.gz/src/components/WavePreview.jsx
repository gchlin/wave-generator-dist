import React, { useRef, useEffect, useState } from 'react';
import { generateWavePoints, pointsToPath, calculateViewBox } from '../utils/waveGenerator';
import { colorSchemes } from '../utils/colorSchemes';
import { downloadSVG, getSVGString } from '../utils/svgExporter';

export default function WavePreview({ params, colorScheme, onAddToHistory }) {
  const svgRef = useRef(null);
  const [time, setTime] = useState(0);
  const animationRef = useRef(null);

  const colors = colorSchemes[colorScheme];
  const { amplitude, wavelength, phase, enableAnimation, frequency } = params;
  const { showWavelengthAnnotation, showAmplitudeAnnotation, showGrid } = params;

  // 動畫循環
  useEffect(() => {
    if (enableAnimation) {
      const animate = () => {
        setTime(t => t + 0.02);
        animationRef.current = requestAnimationFrame(animate);
      };
      animationRef.current = requestAnimationFrame(animate);
    } else {
      setTime(0);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    }

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [enableAnimation]);

  // 生成波形
  const points = generateWavePoints(amplitude, wavelength, phase, time, {
    numWavelengths: 3,
    pointsPerWavelength: 50,
    frequency: frequency
  });

  const pathD = pointsToPath(points, { x: 100, y: 80 });
  const viewBox = calculateViewBox(amplitude, wavelength, 3);

  // 下載 SVG
  const handleDownload = () => {
    if (svgRef.current) {
      const svgString = getSVGString(svgRef.current);
      const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
      downloadSVG(svgString, `wave_A${amplitude}_λ${wavelength}_φ${phase}_${timestamp}.svg`);
    }
  };

  // 加入歷史
  const handleAddToHistory = () => {
    if (svgRef.current) {
      const svgString = getSVGString(svgRef.current);
      onAddToHistory({
        svg: svgString,
        params: { ...params, time: 0 }, // 歷史紀錄儲存靜態版
        timestamp: Date.now(),
        thumbnail: svgString // 可用於預覽
      });
    }
  };

  return (
    <div className="wave-preview">
      <div className="preview-header">
        <h2>📊 即時預覽</h2>
      </div>

      <div className="svg-container" style={{ backgroundColor: colors.background }}>
        <svg
          ref={svgRef}
          viewBox={`${viewBox.x} ${viewBox.y} ${viewBox.width} ${viewBox.height}`}
          xmlns="http://www.w3.org/2000/svg"
          style={{ width: '100%', height: '100%' }}
        >
          {/* 網格 */}
          {showGrid && (
            <g className="grid">
              {Array.from({ length: 20 }, (_, i) => (
                <line
                  key={`h${i}`}
                  x1={viewBox.x}
                  y1={viewBox.y + (i * viewBox.height) / 20}
                  x2={viewBox.x + viewBox.width}
                  y2={viewBox.y + (i * viewBox.height) / 20}
                  stroke={colors.grid}
                  strokeWidth="0.5"
                />
              ))}
              {Array.from({ length: 20 }, (_, i) => (
                <line
                  key={`v${i}`}
                  x1={viewBox.x + (i * viewBox.width) / 20}
                  y1={viewBox.y}
                  x2={viewBox.x + (i * viewBox.width) / 20}
                  y2={viewBox.y + viewBox.height}
                  stroke={colors.grid}
                  strokeWidth="0.5"
                />
              ))}
            </g>
          )}

          {/* 座標軸 */}
          <g className="axes">
            {/* X 軸 */}
            <line
              x1={-20}
              y1={0}
              x2={3 * wavelength * 100 + 20}
              y2={0}
              stroke={colors.axis}
              strokeWidth="2"
            />
            {/* X 軸箭頭 */}
            <polygon
              points={`${3 * wavelength * 100 + 20},0 ${3 * wavelength * 100 + 10},-5 ${3 * wavelength * 100 + 10},5`}
              fill={colors.axis}
            />
            {/* X 軸標籤 */}
            <text
              x={3 * wavelength * 100 + 35}
              y={8}
              fill={colors.labels}
              fontSize="24"
              fontFamily="Arial, sans-serif"
            >
              x
            </text>

            {/* Y 軸 */}
            <line
              x1={0}
              y1={-amplitude * 80 - 20}
              x2={0}
              y2={amplitude * 80 + 20}
              stroke={colors.axis}
              strokeWidth="2"
            />
            {/* Y 軸箭頭 */}
            <polygon
              points={`0,${-amplitude * 80 - 20} -5,${-amplitude * 80 - 10} 5,${-amplitude * 80 - 10}`}
              fill={colors.axis}
            />
            {/* Y 軸標籤 */}
            <text
              x={10}
              y={-amplitude * 80 - 25}
              fill={colors.labels}
              fontSize="24"
              fontFamily="Arial, sans-serif"
            >
              y
            </text>
          </g>

          {/* 波形 */}
          <path
            d={pathD}
            fill="none"
            stroke={colors.wave}
            strokeWidth={colors.lineWidth}
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* 波長標註 */}
          {showWavelengthAnnotation && (
            <g className="wavelength-annotation">
              {/* 雙向箭頭 */}
              <defs>
                <marker
                  id="arrowhead"
                  markerWidth="10"
                  markerHeight="10"
                  refX="5"
                  refY="5"
                  orient="auto"
                >
                  <polygon points="0,0 10,5 0,10" fill={colors.annotation} />
                </marker>
              </defs>
              
              <line
                x1={0}
                y1={amplitude * 80 + 30}
                x2={wavelength * 100}
                y2={amplitude * 80 + 30}
                stroke={colors.annotation}
                strokeWidth="2"
                markerStart="url(#arrowhead)"
                markerEnd="url(#arrowhead)"
                strokeDasharray="5,5"
              />
              
              <text
                x={wavelength * 50}
                y={amplitude * 80 + 55}
                fill={colors.annotation}
                fontSize="20"
                fontFamily="Arial, sans-serif"
                textAnchor="middle"
              >
                λ
              </text>
            </g>
          )}

          {/* 振幅標註 */}
          {showAmplitudeAnnotation && (
            <g className="amplitude-annotation">
              <line
                x1={wavelength * 100 / 4}
                y1={0}
                x2={wavelength * 100 / 4}
                y2={-amplitude * 80}
                stroke={colors.annotation}
                strokeWidth="2"
                markerEnd="url(#arrowhead)"
                strokeDasharray="5,5"
              />
              
              <text
                x={wavelength * 100 / 4 + 15}
                y={-amplitude * 40}
                fill={colors.annotation}
                fontSize="20"
                fontFamily="Arial, sans-serif"
              >
                A
              </text>
            </g>
          )}
        </svg>
      </div>

      <div className="preview-actions">
        <button className="btn-primary" onClick={handleDownload}>
          下載 SVG
        </button>
        <button className="btn-secondary" onClick={handleAddToHistory}>
          加入收藏
        </button>
      </div>

      <div className="param-display">
        <span>A = {amplitude.toFixed(1)}</span>
        <span>λ = {wavelength.toFixed(1)}</span>
        <span>φ = {phase}°</span>
      </div>
    </div>
  );
}
