# 波動圖形產生器

高中物理教學用的波形圖生成工具，可即時調整參數並匯出 SVG 格式圖檔。

## 功能特色

- ✅ 即時預覽波形變化
- ✅ 調整振幅、波長、相位
- ✅ 動畫功能（波的傳播）
- ✅ 自動標註波長和振幅
- ✅ 多種配色方案（投影模式、黑白模式、深色模式）
- ✅ 快速選擇教學預設場景
- ✅ 收藏並批量下載 SVG 檔案

## 安裝與執行

### 本地開發

```bash
# 安裝依賴
npm install

# 啟動開發伺服器
npm run dev

# 在瀏覽器開啟 http://localhost:5173
```

### 建置靜態檔案

```bash
# 建置生產版本
npm run build

# 預覽建置結果
npm run preview
```

## 部署到 GitHub Pages

1. 修改 `vite.config.js` 中的 `base` 路徑為你的 repository 名稱
2. 建置專案：`npm run build`
3. 將 `dist` 資料夾的內容推送到 `gh-pages` 分支

或使用以下腳本自動部署：

```bash
# 建立 deploy.sh
cat > deploy.sh << 'EOF'
#!/usr/bin/env sh
set -e
npm run build
cd dist
git init
git add -A
git commit -m 'deploy'
git push -f git@github.com:你的使用者名稱/wave-generator.git main:gh-pages
cd -
EOF

chmod +x deploy.sh
./deploy.sh
```

## 使用說明

### 基本操作

1. **調整參數**：使用左側控制面板的滑桿調整振幅、波長、相位
2. **即時預覽**：中間區域會即時顯示波形變化
3. **下載圖形**：點選「下載 SVG」按鈕匯出當前圖形
4. **收藏圖形**：點選「加入收藏」保存喜歡的設定
5. **批量下載**：在收藏區選取多個圖形後批量下載

### 快速選擇

使用預設場景快速產生常見的教學圖形：
- **基本波形**：標準正弦波、大振幅、小振幅
- **波長比較**：長波、標準波長、短波
- **相位差**：0°、90°、180° 相位差比較

### 配色方案

- **投影模式**：適合課堂投影，對比度高
- **黑白模式**：適合列印講義
- **深色模式**：適合夜間使用

### 動畫功能

勾選「啟用動畫」可看到波的傳播效果，適合展示波動概念。

## 技術架構

- **前端框架**：React 18
- **建置工具**：Vite 5
- **圖形格式**：SVG（向量圖形，可無限縮放）
- **數學函數**：y(x,t) = A·sin(kx - ωt + φ)

## 專案結構

```
wave-generator/
├── src/
│   ├── components/
│   │   ├── ParameterPanel.jsx      # 參數控制面板
│   │   ├── WavePreview.jsx         # 波形預覽
│   │   └── HistoryPanel.jsx        # 歷史記錄
│   ├── utils/
│   │   ├── waveGenerator.js        # 波形計算
│   │   ├── svgExporter.js          # SVG 匯出
│   │   ├── colorSchemes.js         # 配色方案
│   │   └── presets.js              # 預設場景
│   ├── App.jsx
│   ├── App.css
│   └── main.jsx
├── index.html
├── vite.config.js
└── package.json
```

## 授權

MIT License - 自由使用於教學用途

## 貢獻

歡迎提出 Issue 或 Pull Request 改善此工具！
