export const teachingPresets = {
  '基本波形': [
    { name: '標準正弦波', amplitude: 1, wavelength: 2, phase: 0 },
    { name: '大振幅', amplitude: 2, wavelength: 2, phase: 0 },
    { name: '小振幅', amplitude: 0.5, wavelength: 2, phase: 0 }
  ],
  
  '波長比較': [
    { name: '長波', amplitude: 1, wavelength: 3, phase: 0 },
    { name: '標準波長', amplitude: 1, wavelength: 2, phase: 0 },
    { name: '短波', amplitude: 1, wavelength: 1, phase: 0 }
  ],
  
  '相位差': [
    { name: '同相 (0°)', amplitude: 1, wavelength: 2, phase: 0 },
    { name: '相差 90°', amplitude: 1, wavelength: 2, phase: 90 },
    { name: '反相 (180°)', amplitude: 1, wavelength: 2, phase: 180 }
  ]
};

export const defaultParams = {
  amplitude: 1,
  wavelength: 2,
  phase: 0,
  frequency: 0.5,
  showWavelengthAnnotation: true,
  showAmplitudeAnnotation: true,
  showGrid: false,
  enableAnimation: false
};
