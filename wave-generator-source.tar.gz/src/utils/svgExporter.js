/**
 * 將 SVG 元素轉換為可下載的檔案
 * @param {string} svgString - SVG 字串
 * @param {string} filename - 檔案名稱
 */
export function downloadSVG(svgString, filename = 'wave.svg') {
  const blob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  URL.revokeObjectURL(url);
}

/**
 * 從 React 組件生成完整的 SVG 字串
 * @param {Object} svgElement - SVG DOM 元素
 * @returns {string} 完整的 SVG 字串
 */
export function getSVGString(svgElement) {
  const serializer = new XMLSerializer();
  let svgString = serializer.serializeToString(svgElement);
  
  // 確保有 XML 宣告
  if (!svgString.includes('<?xml')) {
    svgString = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>\n' + svgString;
  }
  
  return svgString;
}

/**
 * 批量下載 SVG 檔案為 ZIP
 * @param {Array} svgDataArray - SVG 資料陣列 [{svg: string, filename: string}, ...]
 */
export async function downloadMultipleSVGsAsZip(svgDataArray) {
  // 簡化版：依序下載（完整版可用 JSZip）
  for (const { svg, filename } of svgDataArray) {
    downloadSVG(svg, filename);
    // 延遲避免瀏覽器阻擋
    await new Promise(resolve => setTimeout(resolve, 100));
  }
}
