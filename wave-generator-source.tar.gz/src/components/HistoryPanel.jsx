import React, { useState } from 'react';
import { downloadSVG, downloadMultipleSVGsAsZip } from '../utils/svgExporter';

export default function HistoryPanel({ history, onClearHistory }) {
  const [selectedItems, setSelectedItems] = useState(new Set());

  const toggleSelection = (index) => {
    const newSelection = new Set(selectedItems);
    if (newSelection.has(index)) {
      newSelection.delete(index);
    } else {
      newSelection.add(index);
    }
    setSelectedItems(newSelection);
  };

  const selectAll = () => {
    setSelectedItems(new Set(history.map((_, idx) => idx)));
  };

  const clearSelection = () => {
    setSelectedItems(new Set());
  };

  const downloadSelected = async () => {
    const itemsToDownload = history
      .filter((_, idx) => selectedItems.has(idx))
      .map((item, idx) => ({
        svg: item.svg,
        filename: `wave_${idx + 1}_A${item.params.amplitude}_λ${item.params.wavelength}_φ${item.params.phase}.svg`
      }));

    if (itemsToDownload.length === 1) {
      downloadSVG(itemsToDownload[0].svg, itemsToDownload[0].filename);
    } else {
      await downloadMultipleSVGsAsZip(itemsToDownload);
    }
  };

  return (
    <div className="history-panel">
      <div className="history-header">
        <h2>📚 已收藏的圖</h2>
        {history.length > 0 && (
          <button className="btn-clear" onClick={onClearHistory}>
            清空
          </button>
        )}
      </div>

      {history.length === 0 ? (
        <div className="empty-state">
          <p>尚無收藏的圖形</p>
          <p className="hint">調整參數後點選「加入收藏」</p>
        </div>
      ) : (
        <>
          <div className="history-actions">
            <button className="btn-small" onClick={selectAll}>
              全選
            </button>
            <button className="btn-small" onClick={clearSelection}>
              清除選取
            </button>
            {selectedItems.size > 0 && (
              <button className="btn-primary btn-small" onClick={downloadSelected}>
                下載所選 ({selectedItems.size})
              </button>
            )}
          </div>

          <div className="history-grid">
            {history.map((item, index) => (
              <div
                key={item.timestamp}
                className={`history-item ${selectedItems.has(index) ? 'selected' : ''}`}
                onClick={() => toggleSelection(index)}
              >
                <div className="thumbnail">
                  <div
                    dangerouslySetInnerHTML={{ __html: item.thumbnail }}
                    style={{ width: '100%', height: '100%' }}
                  />
                </div>
                <div className="item-info">
                  <div className="params-text">
                    A={item.params.amplitude.toFixed(1)}, 
                    λ={item.params.wavelength.toFixed(1)}, 
                    φ={item.params.phase}°
                  </div>
                </div>
                {selectedItems.has(index) && (
                  <div className="checkmark">✓</div>
                )}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
