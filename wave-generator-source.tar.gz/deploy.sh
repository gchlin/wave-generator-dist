#!/usr/bin/env sh

# 終止錯誤時停止執行
set -e

# 建置
echo "正在建置專案..."
npm run build

echo "建置完成！"
echo ""
echo "部署步驟："
echo "1. 將 dist/ 資料夾的內容推送到 GitHub Pages"
echo "2. 或者執行以下指令："
echo ""
echo "  cd dist"
echo "  git init"
echo "  git add -A"
echo "  git commit -m 'deploy'"
echo "  git push -f git@github.com:你的使用者名稱/wave-generator.git main:gh-pages"
echo ""
echo "3. 在 GitHub repository 設定中啟用 GitHub Pages，選擇 gh-pages 分支"
