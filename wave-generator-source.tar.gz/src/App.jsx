import React, { useState } from 'react';
import ParameterPanel from './components/ParameterPanel';
import WavePreview from './components/WavePreview';
import HistoryPanel from './components/HistoryPanel';
import { defaultParams } from './utils/presets';
import { defaultScheme } from './utils/colorSchemes';
import './App.css';

function App() {
  const [params, setParams] = useState(defaultParams);
  const [colorScheme, setColorScheme] = useState(defaultScheme);
  const [history, setHistory] = useState([]);

  const handleAddToHistory = (item) => {
    setHistory([...history, item]);
  };

  const handleClearHistory = () => {
    if (window.confirm('確定要清空所有收藏的圖形嗎？')) {
      setHistory([]);
    }
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1>📊 波動圖形產生器</h1>
        <p className="subtitle">高中物理教學用圖生成工具</p>
      </header>

      <div className="app-content">
        <aside className="sidebar">
          <ParameterPanel
            params={params}
            onParamsChange={setParams}
            colorScheme={colorScheme}
            onColorSchemeChange={setColorScheme}
          />
        </aside>

        <main className="main-content">
          <WavePreview
            params={params}
            colorScheme={colorScheme}
            onAddToHistory={handleAddToHistory}
          />

          <HistoryPanel
            history={history}
            onClearHistory={handleClearHistory}
          />
        </main>
      </div>

      <footer className="app-footer">
        <p>製作教材用波形圖 | 適用於高中物理教學</p>
      </footer>
    </div>
  );
}

export default App;
