/**
 * 生成正弦波的座標點
 * @param {number} amplitude - 振幅 A
 * @param {number} wavelength - 波長 λ
 * @param {number} phase - 相位 φ (度數)
 * @param {number} time - 時間 t (用於動畫)
 * @param {Object} options - 其他選項
 * @returns {Array} 座標點陣列 [[x, y], ...]
 */
export function generateWavePoints(amplitude, wavelength, phase, time = 0, options = {}) {
  const {
    numWavelengths = 3,        // 顯示幾個波長
    pointsPerWavelength = 50,   // 每個波長的採樣點數
    frequency = 0.5             // 頻率 (用於動畫)
  } = options;

  const k = (2 * Math.PI) / wavelength;  // 波數
  const omega = 2 * Math.PI * frequency; // 角頻率
  const phiRad = (phase * Math.PI) / 180; // 相位轉弧度

  const xStart = 0;
  const xEnd = numWavelengths * wavelength;
  const totalPoints = Math.floor(numWavelengths * pointsPerWavelength);
  
  const points = [];
  
  for (let i = 0; i <= totalPoints; i++) {
    const x = xStart + (i / totalPoints) * (xEnd - xStart);
    const y = amplitude * Math.sin(k * x - omega * time + phiRad);
    points.push([x, y]);
  }
  
  return points;
}

/**
 * 將座標點陣列轉換為 SVG path 的 d 屬性
 * @param {Array} points - 座標點陣列
 * @param {Object} scale - 縮放參數
 * @returns {string} SVG path 字串
 */
export function pointsToPath(points, scale = { x: 100, y: 80 }) {
  if (points.length === 0) return '';
  
  const scaledPoints = points.map(([x, y]) => [
    x * scale.x,
    -y * scale.y  // SVG y 軸向下，需要反轉
  ]);
  
  const [firstX, firstY] = scaledPoints[0];
  let path = `M ${firstX},${firstY}`;
  
  for (let i = 1; i < scaledPoints.length; i++) {
    const [x, y] = scaledPoints[i];
    path += ` L ${x},${y}`;
  }
  
  return path;
}

/**
 * 計算 SVG viewBox 參數
 * @param {number} amplitude - 振幅
 * @param {number} wavelength - 波長
 * @param {number} numWavelengths - 波長數量
 * @returns {Object} viewBox 參數
 */
export function calculateViewBox(amplitude, wavelength, numWavelengths = 3) {
  const scale = { x: 100, y: 80 };
  
  const width = numWavelengths * wavelength * scale.x;
  const height = amplitude * 2 * scale.y;
  const padding = 40;
  
  return {
    x: -padding,
    y: -height / 2 - padding,
    width: width + padding * 2,
    height: height + padding * 2
  };
}
